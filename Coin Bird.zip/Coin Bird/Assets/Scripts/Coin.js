﻿#pragma strict

public var points : int = 5;
public var pickedUpBy: String = "Player";
/*
Public varibles will show in Unity Editor
*/
function OnTriggerEnter2D(other:Collider2D)/* Checks for collision */
{
	if (other.CompareTag(pickedUpBy)) /*If there is collision function does these things:*/
	{Debug.Log("Coins! Worth " + points + "points!"); /*give 5 points*/
	Destroy (gameObject); /*Detroys oneself*/
	}
}
